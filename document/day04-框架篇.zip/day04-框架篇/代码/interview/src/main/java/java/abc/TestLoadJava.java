package java.abc;


public class TestLoadJava {
    public static void main(String[] args) {
        System.out.println(TestLoadJava.class.getClassLoader());

    }
}
